<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"/>
    <style>
       #map {
        height: 400px;
        width: 100%;
       }
    </style>
    <title>Contact Us</title>
  </head>
  <body>
    <?php require_once 'header.php'; ?>
    <div class="container">
    <div id="map"></div>
    <script>
      function initMap() {
        var uluru = {lat: 20.1257,lng: 94.9954};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 18,
          center: uluru
          
        });
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
        });
        map.setTilt(45);
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCDfDCDfWALugjTIJFA011TXq4kjpMXsPg &callback=initMap">
    </script>
  </div>
    <?php require_once 'footer.php'; ?>
  </body>
</html>