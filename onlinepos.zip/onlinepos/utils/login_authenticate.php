<?php
require_once 'db_connect.php';
require_once 'util.php';
$util = new util();
session_start();
$username = $_POST['uname'];
$password = $_POST['psw'];
$username = stripslashes($username);
$password = stripslashes($password);
$username = mysqli_real_escape_string($conn, $username);
$password = mysqli_real_escape_string($conn, $password);

$psw = md5($salt . $password);
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ? and password = ?");
$stmt->bind_param("ss", $username, $psw);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $_SESSION['user'] = $row['type'];
    $_SESSION['com_id'] = $row['com_id'];
    if ($_SESSION['user'] === 'admin') {
        $util->redirect('../pos_admin/');
    }
    if ($_SESSION['user'] === 'cashier') {
        $util->redirect('../pos_cashier/cashier.php');
    }
} else {
    echo "<script>alert('Incorrect Username or Password.')</script>
    <meta http-equiv=\"refresh\" content=\"0; url=../index.php\">";
    }
    $_SESSION['uname'] = $username;
$stmt->close();
?>