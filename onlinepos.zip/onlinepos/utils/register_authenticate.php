<?php
require_once 'db_connect.php';
require_once 'util.php';
$util = new util();
session_start();
$flag = 0;
$pattern = "/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/";
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$com_name = $_POST['cname'];
$address = $_POST['address'];
$ph_no = $_POST['ph_no'];
$email = $_POST['email'];
$state = $_POST['state'];
$city = $_POST['city'];
$card = $_POST['card'];
$date = $_POST['date'];
$plan = $_POST['plan'];
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION["email_error"] = "Enter Valid Email";
    $util->redirect('../registerform.php');
    $flag = 1;
}
if (strlen($card) != 17) {
    $_SESSION["card_error"] = "Enter Valid Card Number!";
    $util->redirect('../registerform.php');
    $flag = 1;
}
if (!preg_match($pattern, $date)) {
    $_SESSION["date_error"] = "Please Choose Date!";
    $util->redirect('../registerform.php');
    $flag = 1;
}
if ($state === "empty") {
    $_SESSION["state_error"] = "Please Choose State and City!";
    $util->redirect('../registerform.php');
    $flag = 1;
}
if ($flag === 1) {
    die();
}
$fname = stripcslashes($fname);
$lname = stripcslashes($lname);
$com_name = stripcslashes($com_name);
$address = stripcslashes($address);
$fname = mysqli_real_escape_string($conn, $fname);
$lname = mysqli_real_escape_string($conn, $lname);
$com_name = mysqli_real_escape_string($conn, $com_name);
$address = mysqli_real_escape_string($conn, $address);


$stmt = $conn->prepare("SELECT * FROM credit_cards WHERE card_no = ?");
$stmt->bind_param("s", $card);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    if (strcasecmp($date, $row['expire_date']) == 0) {
        if ($plan === '6') {

            $new_amount = $row['amount'] - 100;
            $stmt = $conn->prepare("UPDATE credit_cards SET amount = ? WHERE card_no = ?");
            $stmt->bind_param("is", $new_amount, $card);
            $stmt->execute();
            $stmt->close();

            $start_date = date("Y-m-d");
            $end_date = date("Y-m-d", strtotime('+6 months'));
            $stmt = $conn->prepare("INSERT INTO companies (own_fname, own_lname, com_name, state, city, com_address, com_ph_no, com_email, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssssss", $fname, $lname, $com_name, $state, $city, $address, $ph_no, $email, $start_date, $end_date);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("SELECT com_id FROM companies WHERE com_email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $com_id = $row['com_id'];

            $rand = $util->userHash();
            $username = $com_name . $rand . '@admin';
            $password = $util->passHash();
            echo $password . "<br>";
            $password = md5($salt . $password);
            $type = 'admin';
            $stmt = $conn->prepare("INSERT INTO users (username, password, type, com_id) VALUES (?, ?, ?, ?)");
            $stmt->bind_param('sssi', $username, $password, $type, $com_id);
            $stmt->execute();
            $stmt->close();

            $rand = $util->userHash();
            $username = $com_name . $rand . '@cashier';
            $password = $util->passHash();
            echo $password;
            $password = md5($salt . $password);
            $type = 'cashier';
            $stmt = $conn->prepare("INSERT INTO users (username, password, type, com_id) VALUES (?, ?, ?, ?)");
            $stmt->bind_param('sssi', $username, $password, $type, $com_id);
            $stmt->execute();
            $stmt->close();

            echo 
            "<p>Your 6 months plan is Registered Successfully</p>
            <meta http-equiv=\"refresh\" content=\"10; url=../index.php\">";
        } else {

            $new_amount = $row['amount'] - 180;
            $stmt = $conn->prepare("UPDATE credit_cards SET amount = ? WHERE card_no = ?");
            $stmt->bind_param("is", $new_amount, $card);
            $stmt->execute();
            $stmt->close();

            $start_date = date("Y-m-d");
            $end_date = date("Y-m-d", strtotime('+12 months'));
            $stmt = $conn->prepare("INSERT INTO companies (own_fname, own_lname, com_name, state, city, com_address, com_ph_no, com_email, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssssss", $fname, $lname, $com_name, $state, $city, $address, $ph_no, $email, $start_date, $end_date);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("SELECT com_id FROM companies WHERE com_email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $com_id = $row['com_id'];

            $rand = $util->userHash();
            $username = $com_name . $rand . '@admin';
            $password = $util->passHash();
            echo $password . "<br>";
            $password = md5($salt . $password);
            $type = 'admin';
            $stmt = $conn->prepare("INSERT INTO users (username, password, type, com_id) VALUES (?, ?, ?, ?)");
            $stmt->bind_param('sssi', $username, $password, $type, $com_id);
            $stmt->execute();
            $stmt->close();

            $rand = $util->userHash();
            $username = $com_name . $rand . '@cashier';
            $password = $util->passHash();
            echo $password;
            $password = md5($salt . $password);
            $type = 'cashier';
            $stmt = $conn->prepare("INSERT INTO users (username, password, type, com_id) VALUES (?, ?, ?, ?)");
            $stmt->bind_param('sssi', $username, $password, $type, $com_id);
            $stmt->execute();
            $stmt->close();

            echo 
            "<p>Your 12 months plan is Registered Successfully</p>
            <meta http-equiv=\"refresh\" content=\"10; url=../index.php\">";        }
    } else {
        $_SESSION['date_not_equal'] = "Invalid Expire Date!";
        $util->redirect('../registerform.php');
        die();
    }
}
?>