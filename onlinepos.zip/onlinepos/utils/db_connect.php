<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "online_pos";
$salt = "a2F1bmdraGFudHdpbm4udWNzbWd5QGdtYWlsLmNvbQ==";
$conn = mysqli_connect($servername, $username, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>