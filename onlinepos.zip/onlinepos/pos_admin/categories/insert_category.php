<?php
require_once '../../utils/util.php';
session_start();
$util = new util();
if (!isset($_SESSION['user'])) {
    # code...
    $util->redirect('../../403.html');;
    die();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Online POS</title>
</head>
<style type="text/css">
        .my-custom-scrollbar {
            position: relative;
            height: 500px;
            overflow: auto;
        }
        
        .table-wrapper-scroll-y {
            display: block;
        }
    </style>
</head>

<script>
$(document).ready(function(){
    $('#insert').on('click',function(){
        var cate_name = $('#cate_name').val();
        $.ajax({
            type:'POST',
            url:'categories/insert_cate_backend.php',
            dataType: "json",
            data:{cate_name:cate_name},
            success:function(data){
                if(data.status == 'ok'){
                    $('#error').hide();
                    $('#cate_name').val('');
                    $('#myTable').append("<tr id = " + cate_name + "><td>" + cate_name + "</td><td><a class='fa fa-trash' href = 'javascript: void(0);' value = '" + cate_name + "'></a></td></tr>");

                    $('a').click(function(){
                    var cate_id = $(this).attr('value');

                       // if we need to remove this row from only HTML
                    $.ajax({
                        url: 'categories/del_record.php',
                        type: 'POST',
                        dataType: "json",
                        data: {cate_id: cate_id} ,
                        success:function(data){
                            if(data.status == 'ok'){
                                $('tr#'+cate_id).css('display', 'none'); 
                                alert('Category deleted successfully');                   
                            }else{
                                alert('Category cannot be deleted');
                            }
                           }
                       });
                 });
                }else{
                    $('#error').show();
                }
            }
        });
    });
    $('a').click(function(){
        var cate_id = $(this).attr('value');

           // if we need to remove this row from only HTML
        $.ajax({
            url: 'categories/del_record.php',
            type: 'POST',
            dataType: "json",
            data: {cate_id: cate_id} ,
            success:function(data){
                if(data.status == 'ok'){
                    $('tr#'+cate_id).css('display', 'none'); 
                    alert('Category deleted successfully');                   
                }else{
                    alert('Category cannot be deleted');
                }
               }
           });
     });
});
</script>

<body style="background-color: #eaecf1;">
    <form method="POST">
        <div class="col-10 md-form input-group mt-3 mb-5">
            <input type="text" id="cate_name" class="form-control" placeholder="Category Name">
            <input type="button" class="btn btn-primary ml-2" id="insert" value="Insert"/>
        </div>
        <label id="error" style="margin-left: 18px; display: none;" class="text text-danger">Please Enter Category Name</label>
        <div class="row container-fluid">
            <div class="col-12 table-wrapper-scroll-y my-custom-scrollbar">
                <table id="myTable" class="table table-bordered table-striped mb-5" style="border-radius: #d4f0f9;">
                    <tr style="border-radius: #007bff;">
                        <th>Category Name</th><th>Action</th>
                    </tr>
                        <?php
require_once '../../utils/db_connect.php';
$sql = 'SELECT * FROM categories WHERE com_id = ' . $_SESSION['com_id'];
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr id = " . $row["cate_id"] . ">";
        echo "<td>" . $row["cate_name"] . "</td>";
        echo "<td><a class = 'btn' href = 'javascript: void(0);' value = '" . $row["cate_id"] . "'><span class = 'fa fa-trash'/></a></td>";
        echo "</tr>";
    }
}
?>                        
                </table>
            </div>
        </div>
    </form>
</body>
</html>