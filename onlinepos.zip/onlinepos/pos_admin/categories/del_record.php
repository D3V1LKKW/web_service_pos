<?php
//include db connection
session_start();
require_once '../../utils/db_connect.php';
$cate_id = $_POST['cate_id'];
$data    = array();

$stmt = $conn->prepare("DELETE FROM categories WHERE (cate_id = (?) or cate_name = (?)) AND com_id = (?)");
$stmt->bind_param("isi", $cate_id, $cate_id, $_SESSION['com_id']);

if ($stmt->execute()) {
    $stmt->close();
    $data['status'] = 'ok';
} else {
    $data['status'] = 'no';
}
echo json_encode($data);

?>
