<?php
session_start();
require_once '../../utils/db_connect.php';
$cate_name = $_POST['cate_name'];
$com_id = $_SESSION['com_id'];
$data = array();
if ($cate_name == '') {
    $data['status'] = 'no';
} else {
    $stmt = $conn->prepare("INSERT INTO categories (cate_name, com_id) VALUES (?, ?)");
    $stmt->bind_param("si", $cate_name, $com_id);
    $stmt->execute();
    $data['status'] = 'ok';
}
echo json_encode($data);
?>