<?php 
	session_start();
	require_once '../utils/util.php';
	$util = new util();
	$_SESSION['com_id'] = null;
	$_SESSION['user'] = null;
	session_unset();
    session_destroy();
	$util->redirect('../index.php');
 ?>