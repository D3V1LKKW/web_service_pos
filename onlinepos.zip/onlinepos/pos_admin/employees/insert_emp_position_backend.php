<?php
session_start();
require_once '../../utils/db_connect.php';
    $pos_name = $_POST['pos_name'];
    $com_id = $_SESSION['com_id'];
    $data = array();

    if ($pos_name == '') {
        $data['status'] = 'no';
    }else{
        $stmt = $conn->prepare("INSERT INTO emp_position (pos_name, com_id) VALUES (?, ?)");
        $stmt->bind_param("si", $pos_name, $com_id);
        $stmt->execute();
        
        $data['status'] = 'ok';
    }
    
    echo json_encode($data);
?>