<?php
    require_once '../../utils/db_connect.php';
    require_once '../../utils/util.php';
    session_start();
    $util = new util();
    if (!isset($_SESSION['user'])) {
    # code...
        $util->redirect('../../403.html');
    ;
    die();
  }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Online POS</title>
</head>
<style type="text/css">
        .my-custom-scrollbar {
            position: relative;
            height: 500px;
            overflow: auto;
        }
        
        .table-wrapper-scroll-y {
            display: block;
        }
    </style>
</head>
<script>
$(document).ready(function(){
    $('#insert').on('click',function(){
        var emp_name = $('#emp_name').val();
        var emp_ph_no = $('#ph_no').val();
        var emp_pos = $('#pos').val();
        $.ajax({
            type:'POST',
            url:'employees/insert_emp_backend.php',
            dataType: "json",
            data:{emp_name:emp_name, emp_ph_no:emp_ph_no, emp_pos:emp_pos},
            success:function(data){
                if(data.status == 'ok'){
                    $('#error').hide();
                    $('#ph_no').val('');
                    $('#emp_name').val('');
                    $('#myTable').append("<tr id = " + emp_ph_no + "><td>" + emp_name + "</td> <td>" + emp_ph_no + "</td> <td>" + emp_pos + "</td><td><a class='fa fa-trash' href = 'javascript: void(0);' value = '" + emp_ph_no+ "'></a></td></tr>");
                    $('a').click(function(){
                        var emp_id = $(this).attr('value');

                           // if we need to remove this row from only HTML
                        $.ajax({
                            url: 'employees/del_employee.php',
                            type: 'POST',
                            dataType: "json",
                            data: {emp_id: emp_id} ,
                            success:function(data){
                                if(data.status == 'ok'){
                                    $('tr#'+emp_id).css('display', 'none'); 
                                    alert('Employee deleted successfully');                   
                                }else{
                                    alert('Employee cannot be deleted');
                                }
                               }
                           });
                     });
                }else{
                    $('#error').show();
                }
            }
        });
    });
    $('a').click(function(){
        var emp_id = $(this).attr('value');

           // if we need to remove this row from only HTML
        $.ajax({
            url: 'employees/del_employee.php',
            type: 'POST',
            dataType: "json",
            data: {emp_id: emp_id} ,
            success:function(data){
                if(data.status == 'ok'){
                    $('tr#'+emp_id).css('display', 'none'); 
                    alert('Employee deleted successfully');                   
                }else{
                    alert('Employee cannot be deleted');
                }
               }
           });
     });
});
</script>

<body style="background-color: #eaecf1;">
    <form method="POST">
        <hr>
        <div class="col-10 md-form input-group mt-3 mb-5">

            <input type="text" id="emp_name" class="form-control" placeholder="Name">
            <input type="text" id="ph_no" class="form-control" placeholder="Ph No">
            <select id="pos">
                <?php
                        $sql = 'SELECT pos_name FROM emp_position WHERE com_id =  ' . $_SESSION['com_id'];
                             $result = mysqli_query($conn, $sql);

                        if (mysqli_num_rows($result) > 0) {
                            while($row = mysqli_fetch_assoc($result)) {
                                echo "<option value = \"" . $row['pos_name'] . "\">";
                                echo $row['pos_name'];
                                echo "</option>";
                                }
                             } 
                ?> 
            </select>
            <input type="button" class="btn btn-primary ml-2" id="insert" value="Insert"/>
        </div>
        <label id="error" style="margin-left: 18px; display: none;" class="text text-danger">Please Fill All Field</label>
        <div class="row container-fluid">
            <div class="col-12 table-wrapper-scroll-y my-custom-scrollbar">
                <table id="myTable" class="table table-bordered table-striped mb-5" style="border-radius: #d4f0f9;">
                    <tr style="border-radius: #007bff;">
                        <th>Name</th>
                        <th>PhNo</th>
                        <th>Position</th>
                        <th>Action</th>
                    </tr>
                        <?php
                            $sql = 'SELECT employees.emp_id, employees.emp_name, employees.emp_ph_no, emp_position.pos_name from employees, emp_position WHERE employees.pos_id = emp_position.pos_id and emp_position.com_id = ' . $_SESSION['com_id'];
                             $result = mysqli_query($conn, $sql);

                             if (mysqli_num_rows($result) > 0) {
                                while($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr id = " . $row["emp_id"] . ">";
                                    echo "<td>" . $row["emp_name"] . "</td>";
                                    echo "<td>" . $row["emp_ph_no"] . "</td>";
                                    echo "<td>" . $row["pos_name"] . "</td>";
                                    echo "<td><a class='fa fa-trash' href = 'javascript: void(0);' value = '" . $row["emp_id"] . "'></a></td>";
                                    echo "</tr>";
                                }
                             } 
                        ?>                        
                </table>
            </div>
        </div>
    </form>
</body>
</html>