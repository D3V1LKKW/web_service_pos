<?php
//include db connection
session_start();
require_once '../../utils/db_connect.php';
$pos_id = $_POST['pos_id'];
$data    = array();

$stmt = $conn->prepare("DELETE FROM emp_position WHERE (pos_id = (?) or pos_name = (?)) AND com_id = (?)");
$stmt->bind_param("isi", $pos_id, $pos_id, $_SESSION['com_id']);

if ($stmt->execute()) {
    $stmt->close();
    $data['status'] = 'ok';
} else {
    $data['status'] = 'no';
}
echo json_encode($data);

?>
