<?php
session_start();
require_once '../../utils/db_connect.php';
    $emp_name = $_POST['emp_name'];
    $emp_ph_no = $_POST['emp_ph_no'];
    $pos_name = $_POST['emp_pos'];
    $data = array();

    if ($emp_name == '' or $emp_ph_no == '' or $pos_name == '') {
        $data['status'] = 'no';
    }else{
        $stmt = $conn->prepare("SELECT emp_position.pos_id FROM emp_position, companies WHERE emp_position.com_id = companies.com_id AND emp_position.pos_name = ? AND companies.com_id=?");
        $stmt->bind_param("ss", $pos_name, $_SESSION['com_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        $pos_id = $row['pos_id'];
        
        //get user data from the database
        $stmt = $conn->prepare("INSERT INTO employees (emp_name, emp_ph_no, pos_id) VALUES (?,?,?)");
        $stmt->bind_param("ssi", $emp_name, $emp_ph_no, $pos_id);
        $stmt->execute();
        
                # code...
        $data['status'] = 'ok';
    }
    
    echo json_encode($data);
?>