<?php
//include db connection
session_start();
require_once '../../utils/db_connect.php';
$emp_id = $_POST['emp_id'];
$data    = array();

$stmt = $conn->prepare("DELETE FROM employees WHERE emp_id = (?) or emp_ph_no = (?)");
$stmt->bind_param("is", $emp_id, $emp_id);

if ($stmt->execute()) {
    $stmt->close();
    $data['status'] = 'ok';
} else {
    $data['status'] = 'no';
}
echo json_encode($data);

?>
