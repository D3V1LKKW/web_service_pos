<?php
    require_once '../../utils/util.php';
    session_start();
    $util = new util();
    if (!isset($_SESSION['user'])) {
    # code...
        $util->redirect('../../403.html');
    ;
    die();
  }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Online POS</title>
</head>
<style type="text/css">
        .my-custom-scrollbar {
            position: relative;
            height: 500px;
            overflow: auto;
        }
        
        .table-wrapper-scroll-y {
            display: block;
        }
    </style>
</head>

<script>
$(document).ready(function(){
    $('#insert').on('click',function(){
        var pos_name = $('#pos_name').val();
        $.ajax({
            type:'POST',
            url:'employees/insert_emp_position_backend.php',
            dataType: "json",
            data:{pos_name:pos_name},
            success:function(data){
                if(data.status == 'ok'){
                    $('#error').hide();
                    $('#pos_name').val('');
                    $('#myTable').append("<tr id = " + pos_name + "><td>" + pos_name + "</td><td><a class='fa fa-trash' href = 'javascript: void(0);' value = '" + pos_name + "'></a></td></tr>");
                    $('a').click(function(){
                        var pos_id = $(this).attr('value');

                           // if we need to remove this row from only HTML
                        $.ajax({
                            url: 'employees/del_position.php',
                            type: 'POST',
                            dataType: "json",
                            data: {pos_id: pos_id} ,
                            success:function(data){
                                if(data.status == 'ok'){
                                    $('tr#'+pos_id).css('display', 'none'); 
                                    alert('Position deleted successfully');                   
                                }else{
                                    alert('Position cannot be deleted');
                                }
                               }
                           });
                     });
                }else{
                    $('#error').show();
                }
            }
        });
    });
        $('a').click(function(){
        var pos_id = $(this).attr('value');

           // if we need to remove this row from only HTML
        $.ajax({
            url: 'employees/del_position.php',
            type: 'POST',
            dataType: "json",
            data: {pos_id: pos_id} ,
            success:function(data){
                if(data.status == 'ok'){
                    $('tr#'+pos_id).css('display', 'none'); 
                    alert('Position deleted successfully');                   
                }else{
                    alert('Position cannot be deleted');
                }
               }
           });
     });
});
</script>

<body style="background-color: #eaecf1;">
    <form method="POST">
        <hr>
        <div class="col-10 md-form input-group mt-3 mb-5">

            <input type="text" id="pos_name" class="form-control" placeholder="Position Name">
            <input type="button" class="btn btn-primary ml-2" id="insert" value="Insert"/>
        </div>
        <label id="error" style="margin-left: 18px; display: none;" class="text text-danger">Please Enter Position Name</label>
        <div class="row container-fluid">
            <div class="col-12 table-wrapper-scroll-y my-custom-scrollbar">
                <table id="myTable" class="table table-bordered table-striped mb-5" style="border-radius: #d4f0f9;">
                    <tr style="border-radius: #007bff;">
                        <th>Position Name</th>
                        <th>Aciton</th>
                    </tr>
                        <?php
                            require_once '../../utils/db_connect.php';
                            $sql = 'SELECT * FROM emp_position WHERE com_id = ' . $_SESSION['com_id'];
                             $result = mysqli_query($conn, $sql);

                             if (mysqli_num_rows($result) > 0) {
                                while($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr id = " . $row["pos_id"] . ">";
                                    echo "<td>" . $row["pos_name"] . "</td>";
                                    echo "<td><a class='fa fa-trash' href = 'javascript: void(0);' value = '" . $row["pos_id"] . "'></a></td>";
                                    echo "</tr>";
                                }
                             } 
                        ?>                        
                </table>
            </div>
        </div>
    </form>
</body>
</html>