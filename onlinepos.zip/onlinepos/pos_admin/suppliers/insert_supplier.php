<?php
    require_once '../../utils/util.php';
    session_start();
    $util = new util();
    if (!isset($_SESSION['user'])) {
        $util->redirect('../../403.html');
    ;
    die();
  }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Online POS</title>
</head>
<style type="text/css">
        .my-custom-scrollbar {
            position: relative;
            height: 400px;
            overflow: auto;
        }
        
        .table-wrapper-scroll-y {
            display: block;
        }
    </style>
</head>

<script>
$(document).ready(function(){
    $('#insert').on('click',function(){
        var sup_name = $('#sup_name').val();
        var ph_no = $('#ph_no').val();
        $.ajax({
            type:'POST',
            url:'suppliers/insert_sup_backend.php',
            dataType: "json",
            data:{sup_name:sup_name, ph_no:ph_no},
            success:function(data){
                if(data.status == 'ok'){
                    $('#error').hide();
                    $('#ph_no').val('');
                    $('#sup_name').val('');
                    $('#myTable').append("<tr id = " + ph_no + "><td>" + sup_name + "</td> <td>" + ph_no + "</td><td><a class = 'btn' href = 'javascript: void(0);' value = '" + ph_no + "'><span class = 'fa fa-trash'/></a></td></tr>");
                    $('a').click(function(){
                        var sup_id = $(this).attr('value');
                           // if we need to remove this row from only HTML
                        $.ajax({
                            url: 'suppliers/del_supplier.php',
                            type: 'POST',
                            dataType: "json",
                            data: {sup_id: sup_id} ,
                            success:function(data){
                                if(data.status == 'ok'){
                                    $('tr#' + ph_no).css('display', 'none'); 
                                    alert('Supplier deleted successfully');                   
                                }else{
                                    alert('Supplier cannot be deleted');
                                }
                               }
                           });
                     });
                }else{
                    $('#error').show();
                }
            }
        });
    });
    $('a').click(function(){
        var sup_id = $(this).attr('value');
           // if we need to remove this row from only HTML
        $.ajax({
            url: 'suppliers/del_supplier.php',
            type: 'POST',
            dataType: "json",
            data: {sup_id: sup_id} ,
            success:function(data){
                if(data.status == 'ok'){
                    $('tr#'+sup_id).css('display', 'none'); 
                    alert('Supplier deleted successfully');                   
                }else{
                    alert('Supplier cannot be deleted');
                }
               }
           });
     });
});
</script>

<body style="background-color: #eaecf1;">
    <form method="POST">
        <hr>
        <div class="col-10 md-form input-group mt-3 mb-5">

            <input type="text" id="sup_name" class="form-control" placeholder="Name">
            <input type="text" id="ph_no" class="form-control" placeholder="Ph No">
            <input type="button" class="btn btn-primary ml-2" id="insert" value="Insert"/>
        </div>
        <label id="error" style="margin-left: 18px; display: none;" class="text text-danger">Please Fill All Fields</label>
        <div class="row container-fluid">
            <div class="col-12 table-wrapper-scroll-y my-custom-scrollbar">
                <table id="myTable" class="table table-bordered table-striped mb-5" style="border-radius: #d4f0f9;">
                    <tr style="border-radius: #007bff;">
                        <th>Name</th>
                        <th>PhNo</th>
                        <th>Action</th>
                    </tr>
                        <?php
                            require_once '../../utils/db_connect.php';
                            $sql = 'SELECT * from suppliers WHERE com_id = ' . $_SESSION['com_id'];
                             $result = mysqli_query($conn, $sql);

                             if (mysqli_num_rows($result) > 0) {
                                while($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr id = ". $row["sup_id"] . ">";
                                    echo "<td>" . $row["sup_name"] . "</td>";
                                    echo "<td>" . $row["sup_ph_no"] . "</td>";
                                    echo "<td><a class = 'btn' href = 'javascript: void(0);' value = '" . $row["sup_id"] . "'><span class = 'fa fa-trash'/></a></td>";
                                    echo "</tr>";
                                }
                             } 
                        ?>                        
                </table>
            </div>
        </div>
    </form>
</body>
</html>