<?php
//include db connection
session_start();
require_once '../../utils/db_connect.php';
$sup_id = $_POST['sup_id'];
$data    = array();

$stmt = $conn->prepare("DELETE FROM suppliers WHERE (sup_id = (?) or sup_ph_no = (?)) AND com_id = (?)");
$stmt->bind_param("isi", $sup_id, $sup_id, $_SESSION['com_id']);

if ($stmt->execute()) {
    $stmt->close();
    $data['status'] = 'ok';
} else {
    $data['status'] = 'no';
}
echo json_encode($data);

?>
