<?php
session_start();
require_once '../../utils/db_connect.php';
    $sup_name = $_POST['sup_name'];
    $sup_ph_no = $_POST['ph_no'];
    $com_id = $_SESSION['com_id'];
    $data = array();

    if ($sup_name == '' or $sup_ph_no == '') {
        $data['status'] = 'no';
    }else{
        $stmt = $conn->prepare("INSERT INTO suppliers (sup_name, sup_ph_no, com_id) VALUES (?,?,?)");
        $stmt->bind_param("ssi", $sup_name, $sup_ph_no, $com_id);
        $stmt->execute();

        $data['status'] = 'ok';

    }
    
    
    echo json_encode($data);
?>