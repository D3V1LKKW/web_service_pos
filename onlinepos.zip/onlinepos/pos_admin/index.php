<?php 
  require_once '../utils/util.php';
    session_start();
    $util = new util();
    if (!isset($_SESSION['user']) || ($_SESSION['user'] === 'cashier')) {
    # code...
        $util->redirect('../403.html');
    ;
    die();
  }
 ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script>
<style>

.left {

    display: table-cell;
    padding: 0px;
    margin: 0px;
}
.middle {

    display: table-cell;
    width:100%;
    padding: 0px;
    margin: 0px;
}
.right {

    display: table-cell;
    padding: 0px;
    margin: 0px;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #007bff;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 20px;
}

.sidenav a {
  padding: 8px 8px 15px 20px;
  text-decoration: none;
  font-size: 20px;
  color: #ffffff;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #000000;
}

.sidenav .closebtn {
  position: absolute;
  top: 0px;
  right: 0px;
  font-size: 30px;
  margin-left: 80px;
}

#main {
  transition: margin-left .5s;
}
#place {
  transition: margin-left .5s;
  margin-left: 15px;
  margin-right: 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>
<title>Online POS</title>
<body>

<div id="mySidenav" class="sidenav">
  <!--<a class="fa fa-dashboard" href="javascript:void(0)" id="openDashboard" >&nbsp;Dashboard</a>!-->
  <!--<a class="fa fa-area-chart" href="javascript:void(0)" id="openGraph" >&nbsp;Graphs</a>!-->
  <a class="fa fa-television" href="javascript:void(0)" id="openSale" >&nbsp;Sale</a>
  <a class="fa fa-tags" href="javascript:void(0)" id="openCate">&nbsp;Category</a>
  <a class="fa fa-signal" href="javascript:void(0)" id="openEmpPos">&nbsp;Position</a>
  <a class="fa fa-id-card" href="javascript:void(0)" id="openEmp">&nbsp;Employee</a>
  <!--<a class="fa fa-search" href="javascript:void(0)" id="openSearch">&nbsp;Search</a>!-->
  <a class="fa fa-archive" href="javascript:void(0)" id="openItem">&nbsp;Items</a>
  <a class="fa fa-group" href="javascript:void(0)" id="openSup">&nbsp;Suppliers</a>
</div>

<div id="main">
  <div class="left"><span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span></div>
  <div class="middle" style="text-align: center;"><label id="name" style="font-size: 40px;">Dashboard</label></div>
  <div class="dropdown right">
    <button class="btn dropdown-toggle fa fa-user-circle" type="button" data-toggle="dropdown">&nbsp;<?php echo $_SESSION['uname']; ?>
    <span class="caret"></span></button>
    <ul class="dropdown-menu">
      <li><a href="#" class="fa fa-gear" style="color: black;">&nbsp;Setting</a></li>
      <li><a href="logout.php" class="fa fa-sign-out" style="color: black;">&nbsp;Logout</a></li>
    </ul>
  </div>
</div>
<hr>
<div id="place"div>
<script>
  var flag = true;
  function openNav() {
    if (flag) {
      document.getElementById("mySidenav").style.width = "200px";
      document.getElementById("main").style.marginLeft = "200px";
      document.getElementById("place").style.marginLeft = "200px";
      flag = false;
    }else{document.getElementById("mySidenav").style.width = "0";
      document.getElementById("main").style.marginLeft= "0";
      document.getElementById("place").style.marginLeft = "0";
      flag = true;
    }
  }

  var options = {
  title: {
    text: "Column Chart in jQuery CanvasJS"              
  },
  data: [              
  {
    // Change type to "doughnut", "line", "splineArea", etc.
    type: "column",
    dataPoints: [
      { label: "apple",  y: 10  },
      { label: "orange", y: 15  },
      { label: "banana", y: 25  },
      { label: "mango",  y: 30  },
      { label: "grape",  y: 28  },
      { label: "pineapple", y: 60  }
    ]
  }
  ]
};
  
$(document).ready(function(){
  $('#place').load('admin_cash/admin_cash.php');
    $('#name').html("Sale");
  $('#openDashboard').on('click',function(){
    $('#place').html("<h1>Hello World</h1>");
    $('#name').html("Dashboard");
  });
  $('#openSale').on('click',function(){
    $('#place').load('admin_cash/admin_cash.php');
    $('#name').html("Sale");
  });
  $('#openCate').on('click',function(){
    $('#place').load('categories/insert_category.php');
    $('#name').html("Categories");
  });
  $('#openEmpPos').on('click',function(){
    $('#place').load('employees/insert_emp_position.php');
    $('#name').html("Positions");
  });
  $('#openEmp').on('click',function(){
    $('#place').load('employees/insert_employee.php');
    $('#name').html("Employees");
  });
  $('#openItem').on('click',function(){
    $('#place').load('items/insert_item.php');
    $('#name').html("Items");
  });
  $('#openSup').on('click',function(){
    $('#place').load('suppliers/insert_supplier.php');
    $('#name').html("Suppliers");
  });
  $('#openGraph').on('click',function(){
    $("#place").CanvasJSChart(options);
    $('#name').html("Graph");
  });
  $('#openSearch').on('click',function(){
    $("#place").load('item_search/item_search.php');
    $('#name').html("Search");
  });

});
</script>
   
</body>
</html> 
