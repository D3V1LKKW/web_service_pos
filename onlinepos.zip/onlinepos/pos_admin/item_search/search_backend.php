<?php
session_start();
require_once '../../utils/db_connect.php';
$data = array();
$code = $_POST['barcode'];

$stmt = $conn->prepare("SELECT * FROM items WHERE item_barcode = ?");
$stmt->bind_param("s", $code);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
	$row = $result->fetch_assoc();
    $data['result'] = $row;
}
$data['status'] = 'ok';
echo json_encode($data);
?>