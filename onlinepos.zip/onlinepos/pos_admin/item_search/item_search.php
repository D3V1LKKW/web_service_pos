<?php
require_once '../../utils/db_connect.php';

    require_once '../../utils/util.php';
    session_start();
    $util = new util();
    if (!isset($_SESSION['user'])) {
    # code...
        $util->redirect('../../403.html');
    ;
    die();
  }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Online POS</title>
</head>
<style type="text/css">
        .my-custom-scrollbar {
            position: relative;
            height: 500px;
            overflow: auto;
        }
        
        .table-wrapper-scroll-y {
            display: block;
        }
    </style>
</head>

<script>
$(document).ready(function(){
    $('#barcode').keypress(function(){
        var barcode = $('#barcode').val();
        alert(barcode);
        $.ajax({
            type:'POST',
            url:'item_search/search_backend.php',
            dataType: "json",
            data:{barcode:barcode},
            success:function(data){
                if(data.status == 'ok'){
                	$('no_item').hide();
                    $('#myTable').append("<tr><td>" + data.result.item_barcode + "</td> <td>" + data.result.item_name + "</td> <td>" + data.result.sell_price + "</td> <td>" + data.result.quantity + "</td> <td>" + data.result.reorder_level + "</td></tr>");
                }
            }
        });
    });
});
</script>

<body style="background-color: #eaecf1;">
    <form method="POST">
        <div class="col-10 md-form input-group mt-3 mb-5">
              <div class="dropdown right">
			    <button class="btn dropdown-toggle fa fa-search" type="button" data-toggle="dropdown">&nbsp; Search
			    <span class="caret"></span></button>
			    <ul class="dropdown-menu">
			      <li><a id="by_cate" href="javascript:void(0)" class="fa fa-gear" style="color: black;">&nbsp;By Category</a></li>
			      <li><a id="by_barcode" href="javascript:void(0)" class="fa fa-sign-out" style="color: black;">&nbsp;By Barcode</a></li>
			    </ul>
			  </div>
			  <select id="cate" style="display: none">
                <?php
                        $sql = 'SELECT cate_name FROM categories WHERE com_id =  ' . $_SESSION['com_id'];
                             $result = mysqli_query($conn, $sql);

                        if (mysqli_num_rows($result) > 0) {
                            while($row = mysqli_fetch_assoc($result)) {
                                echo "<option value = \"" . $row['cate_name'] . "\">";
                                echo $row['cate_name'];
                                echo "</option>";
                                }
                             } 
                ?> 
            </select>
            <input type="text" id="barcode" class="form-control" placeholder="Barcode" >
        </div>
        <label id="error" style="margin-left: 18px; display: none;" class="text text-danger">Please Enter Category Name</label>
        <div class="row container-fluid">
            <div class="col-12 table-wrapper-scroll-y my-custom-scrollbar">
                <table id="myTable" class="table table-bordered table-striped mb-5" style="border-radius: #d4f0f9;">
                    <tr style="border-radius: #007bff;">
                        <th>barcode</th>
                        <th>name</th>
                        <th>buy price</th>
                        <th>sell price</th>
                        <th>quantity</th>
                        <th>reorder level</th>
                        <th>category</th>
                        <th>supplier</th>
                    </tr>                      
                </table>
                <div id="no_item">No Item To Display</div>
            </div>
        </div>
    </form>
    <script>
	    $(document).ready(function(){
		  $('#by_cate').on('click',function(){
		    $("#cate").show();
		    $("#barcode").hide();
		  });
		  $('#by_barcode').on('click',function(){
		    $("#barcode").show();
		    $("#cate").hide();
		  });

	});
</script>
</body>
</html>