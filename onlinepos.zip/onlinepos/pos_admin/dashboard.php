<html>
<head>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="http://code.highcharts.com/highcharts.js"></script>
<script src="http://code.highcharts.com/modules/exporting.js"></script>
<style>
  a{
    border: 1px solid gray;
    border-radius: 10px;
    padding: 10px;
    text-decoration:none;
    float:left;
    margin:4px;
    text-align:center;
    display: block;
    color: green;
  }
</style>
<script>
$(function () {
 
  //create a variable so we can pass the value dynamically
  var chartype = 'line';
 
  //On page load call the function setDynamicChart
  setDynamicChart(chartype);
 
  //jQuery part - On Click call the function setDynamicChart(dynval) and pass the chart type
  $('.option').click(function(){
    //get the value from 'a' tag
    var chartype = $(this).attr('id');
    setDynamicChart(chartype);
  });
 
  //function is created so we pass the value dynamically and be able to refresh the HighCharts on every click
 
  function setDynamicChart(chartype){
    $('#container').highcharts({
      chart: {
        type: chartype
      },
      title: {
        text: 'Change Chart type dynamically with jQuery'
      },
      xAxis: {
        categories: ['Firefox', 'IE', 'Chrome', 'Safari', 'Opera', 'Others']
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Total fruit consumption'
        }
      },
      plotOptions: {
        //this need only for pie chart
        pie: {
          allowPointSelect: true,
          cursor: 'pointer'
        }
      },
      series: [{
        data: [
          ['Firefox',   45.0],
          ['IE',       26.8],
          ['Chrome',  15.2],
          ['Safari',    8.5],
          ['Opera',     6.2],
          ['Others',   0.7]
        ]
      }]
    });
  }
    });
</script>
</head>
<body>
<div style="width: 50%; margin: 0 auto; height: 100px; text-align:center;">
  <a href="javascript:void(0);" class="option" id="line">Line Chart</a>
  <a href="javascript:void(0);" class="option" id="bar">Bar Chart</a>
  <a href="javascript:void(0);" class="option" id="column">Column Chart</a>
  <a href="javascript:void(0);" class="option" id="pie">Pie Chart</a>
</div>
 
<div id="container" style="width: 50%;min-width: 310px; height: 400px; margin: 0 auto"></div>
</body>
