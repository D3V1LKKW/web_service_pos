<?php
//include db connection
require_once '../../utils/db_connect.php';
$item_id = $_POST["item_id"];
$data    = array();

$stmt = $conn->prepare("DELETE FROM items WHERE item_id = ? or item_name = ?");
$stmt->bind_param("is", $item_id, $item_id);

if ($stmt->execute()) {
    $stmt->close();
    $data['status'] = 'ok';
} else {
    $data['status'] = 'no';
}
echo json_encode($data);

?>