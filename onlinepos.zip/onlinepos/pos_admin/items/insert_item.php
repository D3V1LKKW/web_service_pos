<?php
    require_once '../../utils/db_connect.php';
    require_once '../../utils/util.php';
    session_start();
    $util = new util();
    if (!isset($_SESSION['user'])) {
    # code...
        $util->redirect('../../403.html');
    ;
    die();
  }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Online POS</title>
</head>
<style type="text/css">
        .my-custom-scrollbar {
            position: relative;
            height: 500px;
            overflow: auto;
        }
        
        .table-wrapper-scroll-y {
            display: block;
        }
    </style>
</head>

<script>
$(document).ready(function(){
    $('#insert').on('click',function(){
        var barcode = $('#barcode').val();
        var name = $('#item_name').val();
        var bprice = $('#bprice').val();
        var sprice = $('#sprice').val();
        var qty = $('#qty').val();
        var reorder = $('#reorder').val();
        var cate = $('#cate').val();
        var sup = $('#sup').val();
        $.ajax({
            type:'POST',
            url:'items/insert_backend.php',
            dataType: "json",
            data:{barcode:barcode, name:name, bprice:bprice, sprice:sprice, qty:qty, reorder:reorder, cate:cate, sup:sup},
            success:function(data){
                if(data.status == 'ok'){
                    $('#error').hide();
                    $('#barcode').val('');
                    $('#item_name').val('');
                    $('#myTable').append("<tr id = " + barcode + "><td>" + barcode + "</td> <td>" + name + "</td> <td>" + bprice + "</td><td>" + sprice + "</td> <td>" + qty + "</td> <td>" + reorder + "</td> <td>" + cate + "</td><td>" + sup + "</td><td><a class='fa fa-trash' href = 'javascript: void(0);' value = '" + barcode + "'></a></td></tr>");
                    $('a').click(function(){
                        var item_id = $(this).attr('value');
                           // if we need to remove this row from only HTML
                        $.ajax({
                            url: 'items/del_item.php',
                            type: 'POST',
                            dataType: "json",
                            data: {item_id: item_id} ,
                            success:function(data){
                                if(data.status == 'ok'){
                                    $('tr#'+item_id).css('display', 'none'); 
                                    alert('Item deleted successfully');                   
                                }else{
                                    alert('Item cannot be deleted');
                                }
                               }
                           });
                     });
                }else if(data.status == 'bc_error'){
                    alert("Duplicate Barcode");
                }else{
                    $('#error').show();
                }
            }
        });
    });
    $('a').click(function(){
        var item_id = $(this).attr('value');
           // if we need to remove this row from only HTML
        $.ajax({
            url: 'items/del_item.php',
            type: 'POST',
            dataType: "json",
            data: {item_id: item_id} ,
            success:function(data){
                if(data.status == 'ok'){
                    $('tr#'+item_id).css('display', 'none'); 
                    alert('Item deleted successfully');                   
                }else{
                    alert('Item cannot be deleted');
                }
               }
           });
     });
});
</script>

<body style="background-color: #eaecf1;">
    <form method="POST">
        <div class="col-12 md-form input-group mt-3 mb-5">

            <input type="text" id="barcode" class="form-control" placeholder="Barcode">
            <input type="text" id="item_name" class="form-control" placeholder="Name">
            <input type="number" id="bprice" min="1" class="form-control" placeholder="Buy Price">
            <input type="number" id="sprice" min="1" class="form-control" placeholder="Sell Price">
            <input type="number" id="qty" min="1" class="form-control" placeholder="Quantity">
            <input type="number" id="reorder" min="1" class="form-control" placeholder="Reorder Level">
            <select id="cate">
                <?php
                        $sql = 'SELECT cate_name FROM categories WHERE com_id =  ' . $_SESSION['com_id'];
                             $result = mysqli_query($conn, $sql);

                        if (mysqli_num_rows($result) > 0) {
                            while($row = mysqli_fetch_assoc($result)) {
                                echo "<option value = \"" . $row['cate_name'] . "\">";
                                echo $row['cate_name'];
                                echo "</option>";
                                }
                             } 
                ?> 
            </select>
            <select id="sup">
                <?php
                        $sql = 'SELECT sup_name FROM suppliers WHERE com_id =  ' . $_SESSION['com_id'];
                             $result = mysqli_query($conn, $sql);

                        if (mysqli_num_rows($result) > 0) {
                            while($row = mysqli_fetch_assoc($result)) {
                                echo "<option value = \"" . $row['sup_name'] . "\">";
                                echo $row['sup_name'];
                                echo "</option>";
                                }
                             } 
                ?> 
            </select>
            <input type="button" class="btn btn-primary ml-2" id="insert" value="Insert"/>
        </div>
        <label id="error" style="margin-left: 18px; display: none;" class="text text-danger">Please Fill All Fields</label>
        <div class="row container-fluid">
            <div class="col-12 table-wrapper-scroll-y my-custom-scrollbar">
                <table id="myTable" class="table table-bordered table-striped mb-5" style="border-radius: #d4f0f9;">
                    <tr style="border-radius: #007bff;">
                        <th>barcode</th>
                        <th>name</th>
                        <th>buy price</th>
                        <th>sell price</th>
                        <th>quantity</th>
                        <th>reorder level</th>
                        <th>category</th>
                        <th>supplier</th>
                        <th>Action</th>  
                    </tr>
                        <?php
                            $sql = 'SELECT items.item_id, items.item_barcode, items.item_name, items.buy_price, items.sell_price, items.quantity, items.reorder_level, categories.cate_name, suppliers.sup_name FROM items, categories, suppliers WHERE items.cate_id = categories.cate_id AND items.sup_id = suppliers.sup_id AND suppliers.com_id = ' . $_SESSION['com_id'];
                             $result = mysqli_query($conn, $sql);

                             if (mysqli_num_rows($result) > 0) {
                                while($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr id = " .$row["item_id"] . ">";
                                    echo "<td>" . $row["item_barcode"] . "</td>";
                                    echo "<td>" . $row["item_name"] . "</td>";
                                    echo "<td>" . $row["buy_price"] . "</td>";
                                    echo "<td>" . $row["sell_price"] . "</td>";
                                    echo "<td>" . $row["quantity"] . "</td>";
                                    echo "<td>" . $row["reorder_level"] . "</td>";
                                    echo "<td>" . $row["cate_name"] . "</td>";
                                    echo "<td>" . $row["sup_name"] . "</td>";
                                    echo "<td><a class = 'btn' href = 'javascript: void(0);' value = '" . $row["item_id"] . "'><span class = 'fa fa-trash'/></a></td>";
                                    echo "</tr>";
                                }
                             } 
                        ?>                        
                </table>
            </div>
        </div>
    </form>
</body>
</html>