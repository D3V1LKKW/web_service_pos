<?php
session_start();
require_once '../../utils/db_connect.php';
    $code = $_POST['barcode'];
    $name = $_POST['name'];
    $bprice = $_POST['bprice'];
    $sprice = $_POST['sprice'];
    $qty  = $_POST['qty'];
    $reorder = $_POST['reorder'];
    $cate = $_POST['cate'];
    $sup = $_POST['sup'];
    $flag = 1;
    $data = array();

    if ($code == '' or $name == '' or $bprice == '' or $sprice == '' or $qty == '' or $reorder == '' or $cate == '' or $sup == '') {
        $data['status'] = 'no';
    }else{
        $stmt = $conn->prepare("SELECT cate_id FROM categories WHERE cate_name = ? AND com_id=?");
        $stmt->bind_param("ss", $cate, $_SESSION['com_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        $cate_id = $row['cate_id'];

        $stmt = $conn->prepare("SELECT sup_id FROM suppliers WHERE sup_name = ? AND com_id=?");
        $stmt->bind_param("ss", $sup, $_SESSION['com_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        $sup_id = $row['sup_id'];


        $stmt = $conn->prepare("SELECT items.item_barcode FROM items, categories WHERE items.cate_id = categories.cate_id AND categories.com_id = ?");
        $stmt->bind_param("s", $_SESSION['com_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        while($row = $result->fetch_assoc()){
            if ($row['item_barcode'] == $code) {
                $flag = 0;
                $data['status'] = 'bc_error';
            }
        }
        if($flag == 1){
            $stmt = $conn->prepare("INSERT INTO items (item_barcode, item_name, buy_price, sell_price, quantity, reorder_level, cate_id, sup_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssiiiiii", $code, $name, $bprice, $sprice, $qty, $reorder, $cate_id, $sup_id);
            $stmt->execute();
            
                    # code...
            $data['status'] = 'ok';
        
    }
    }
    echo json_encode($data);
    $flag = 1;
?>