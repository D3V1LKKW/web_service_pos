<?php
session_start();
require_once '../utils/db_connect.php';
if (!empty($_POST['barcode']) and !empty($_POST['qty']) and $_POST['qty'] > 0) {
    $code = $_POST['barcode'];
    $qty  = $_POST['qty'];
    $data = array();
    
    //get user data from the database
    $stmt = $conn->prepare("SELECT items.* FROM items, categories, companies WHERE items.cate_id = categories.cate_id AND categories.com_id = companies.com_id AND items.item_barcode = ? AND companies.com_id = ?");
    $stmt->bind_param("ss", $code, $_SESSION['com_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $row            = $result->fetch_assoc();
        if ($qty <= $row['quantity']) {
            # code...
            $data['status'] = 'ok';
            $data['result'] = $row;
            $data['item_id'] = $row["item_id"];
            $data['sell_price'] = $row["sell_price"];
            $data['qty'] = $qty;
            $data['total'] = $qty * $row['sell_price'];
        }else{
            $data['status'] = 'qtyerr';
            $data['result'] = '';
            $data['qty'] = '';
            $data['total'] = '';
        }
    } else {
        $data['status'] = 'not';
        $data['result'] = '';
        $data['qty'] = '';
        $data['total'] = '';
    }
    
    
    #if($query->num_rows > 0){
    #   $userData = $query->fetch_assoc();
    #   $data['status'] = 'ok';
    #   $data['result'] = $userData;
    #}else{
    #   $data['status'] = 'err';
    #  $data['result'] = '';
    #}
    
    //returns data as JSON format
    echo json_encode($data);
}
?>