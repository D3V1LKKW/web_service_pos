<?php
    require_once '../utils/util.php';
    session_start();
    $util = new util();
    if (!isset($_SESSION['user'])) {
            $util->redirect('../403.html');
    ;
    die();
  }
?>
<!DOCTYPE html>
<html>
 
<head>
    <title>Online POS</title>
    <style type="text/css">
        .my-custom-scrollbar {
            position: relative;
            height: 450px;
            overflow: auto;
        }
        
        .table-wrapper-scroll-y {
            display: block;
        }
        div{
            margin: 0px;
            padding: 0px;
        }
        #prdno {
            display: none;
        }
        #qtyno {
            display: none;
        }
    </style>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script
  src="https://code.jquery.com/jquery-3.4.1.js"
  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
  crossorigin="anonymous"></script>

</head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>POS system</title>

<script>
$(document).ready(function(){
    var final_total = 0;
    var sale_id;
    $('#getProduct').on('click',function(){
        var barcode = $('#barcode').val();
        var qty = $('#qty').val();
        $.ajax({
            type:'POST',
            url:'getProduct.php',
            dataType: "json",
            data:{barcode:barcode, qty:qty},
            success:function(data){
                if(data.status == 'ok'){
                    $('#prdno').hide();
                    $('#qtyno').hide();
                    $('#barcode').val('');
                    $('#qyt').val('');
                    $('#after').after("<tr><td>" + data.result.item_barcode + "</td> <td>" + data.result.item_name + "</td> <td>" + data.result.sell_price + "</td> <td>" + data.qty + "</td> <td>" + data.total + "</td></tr>");
                    final_total = final_total + data.total;
                    document.getElementById('total_p').innerHTML = final_total;
                }else if (data.status == 'qtyerr'){
                    $('#qtyno').show();
                    $('#prdno').hide();
                }else{
                    $('#prdno').show();
                    $('#qtyno').hide();
                }
            }
        });
    });
    $('#sale').on('click', function(){
        var rows = [];
        $("#myTable").find("td").each(  function(i,el){ 
            rows.push( $(el).html() );
        }); 
        var jsonString = JSON.stringify(rows);
        $.ajax({
        type: "POST",
        url: "insert_table_data.php",
        data: {data : jsonString}, 
        dataType:"json",
        cache: false,

        success: function(data){
            if(data.status == 'ok'){
                alert('Sale Complete');
                sale_id = $data['voc_id'];
            }
    }
    });
});
});
function printDiv(divName){
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
            document.location.reload(true);
        }
</script>

<body style="background-color: #eaecf1;">
    <form method="POST">
        <div>
            <label style="margin-left: 20px; font-size: 50px; margin-bottom: 0px; padding-bottom: 0px;">Sale</label>
            <label style="float: right; font-size: 20px; margin-right: 20px; margin-bottom: 0px; padding-bottom: 0px;">
                <?php
                    echo $_SESSION['user'];
                ?>
            </label>
        </div>
        <hr>
        <div class="col-11 md-form input-group mt-3 mb-5">

            <input type="text" id="barcode" class="form-control" placeholder="Enter Item name or bar code">
            <div class="input-group-append" style="padding-left: 1em;">
                <input type="number" id="qty" placeholder="Quantity" min="1" />
                <input type="button" class="btn btn-primary ml-2" id="getProduct" value="Get Details"/>
            </div>
        </div>
        <label id="prdno" style="color: red; margin-left: 14px;">Product Not Found </label>
        <label id="qtyno" style="color: red; margin-left: 14px;">Quantity Not Available</label> 
        <div class="row container-fluid">
            <div class="col-12 table-wrapper-scroll-y my-custom-scrollbar" id = 'table'>
                <table id="myTable" class="table table-bordered table-striped mb-5" style="border-radius: #d4f0f9;">
                    <tr style="border-radius: #007bff;" id="after">
                        <th>barcode</th>
                        <th>name</th>
                        <th>price</th>
                        <th>quantity</th>
                        <th>total</th>
                    </tr>
                    <tr><td colspan="3"></td><td style="text-align: right;">Total : </td><td id="total_p"></td></tr>
                </table>
            </div>
        </div>
        <div>
            <button class="btn btn-md btn-primary m-0 px-3 ml-5" onclick="printDiv('table')" id="sale" style="border-radius: 5px; width: 90px;" type="Submit">Sale</button>
            <button class="btn btn-md btn-primary m-0 px-3 ml-2" style="border-radius: 5px; width: 90px;" type="button">Cancel</button>
        </div>
    </form>
</body>

</html>