<?php
	session_start();
	require_once '../utils/db_connect.php';
	require_once '../utils/util.php';
	$test = json_decode($_POST['data']);
	$data = array();
	$arr = array();
	$total = 0;
	$a = '';

	$util = new util();

	$sale_id = date("Y-m-d") . $util->userHash();
	
	foreach ($test as $d) {
		$a = $a.$d.',';
	}
	$splited = explode(',', $a);

	foreach (array_keys($splited, ' ') as $key) {
    	unset($splited[$key]);
	}

	$splited = array_filter(array_map('trim', $splited));

	for ($i=0; $i < sizeof($splited)-5; $i = $i + 5) { 
		$b = array_slice($splited, $i, 5);

		$stmt = $conn->prepare("SELECT items.* FROM items, categories, companies WHERE items.cate_id = categories.cate_id AND categories.com_id = companies.com_id AND items.item_barcode = ? AND companies.com_id = ?");
	    $stmt->bind_param("ii", $b[0], $_SESSION['com_id']);
	    $stmt->execute();
	    $result = $stmt->get_result();
	    $row = $result->fetch_assoc();

		$stmt = $conn->prepare("INSERT INTO sales  VALUES (?, ?, ?, ?, now(), ?)");
        $stmt->bind_param("siiis", $sale_id, $row['item_id'], $b[3], $b[4], $_SESSION['user']);
        $stmt->execute();

        $total = $total + $b[4];
	}

		$stmt = $conn->prepare("INSERT INTO voucher (sale_id, total_price, voc_date)  VALUES (?, ?, now())");
        $stmt->bind_param("si", $sale_id, $total);
        $stmt->execute();
     	$data['voc_id'] = $sale_id;

	$data['status'] = 'ok';
   	echo json_encode($data);
?>