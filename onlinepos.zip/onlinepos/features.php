<!DOCTYPE html>
<html lang="en">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"/>
  <style>
    table {border-spacing: 15px;}
  </style>
  <title>Features</title>
</head>

<body> 
  <?php require_once 'header.php'; ?>
  <br>
  <br>
    <div class="container">
      <div class="row">
        <div class="col-sm-4">
          <div class="text-center">
          <h3><img src="images/inventory.png" style="width:30%;" alt="ing-fluit img-responsive">
          <br><b>Inventory Management</b></h3>
          </div>
           <p>The process of ordering, storing, and using a company's inventory.</p>
        </div>
        <div class="col-sm-4">
          <div class="text-center">  
          <h3><img src="images/employee.png" style="width:30%;" alt="ing-fluit img-responsive">
          <br><b>Employee Management</b></h3>
          </div>
           <p>The management of subordinates in an organization. Often, large organization have many of these functions performed by a specialisit department, such as personal or human resources, but all line managers are still requried to supervise and administer the activities, and ensure the well-being, of the staff thaat report to them.</p>
        </div>
        <div class="col-sm-4">
          <div class="text-center">  
          <h3><img src="images/report.png" style="width:30%;" alt="ing-fluit img-responsive">
          <br><b>Sale Report</b></h3>
          </div>
           <p>A sale analysis report shows the trend that occur in a company's sale volume over time.In its most baisc form, a sale analysis report shows whether sales are increasing or declining.</p>
        </div>  
      </div>
    </div><br><br><br>

<div class="container">
      <div class="row">
        <div class="col-sm-4">
          <div class="text-center">
          <h3><img src="images/inventory.png" style="width:30%;" alt="ing-fluit img-responsive">
          <br><b>Inventory Management</b></h3>
          </div>
           <p>The process of ordering, storing, and using a company's inventory.</p>
        </div>
        <div class="col-sm-4">
          <div class="text-center">  
          <h3><img src="images/employee.png" style="width:30%;" alt="ing-fluit img-responsive">
          <br><b>Employee Management</b></h3>
          </div>
           <p>The management of subordinates in an organization. Often, large organization have many of these functions performed by a specialisit department, such as personal or human resources, but all line managers are still requried to supervise and administer the activities, and ensure the well-being, of the staff thaat report to them.</p>
        </div>
        <div class="col-sm-4">
          <div class="text-center">  
          <h3><img src="images/report.png" style="width:30%;" alt="ing-fluit img-responsive">
          <br><b>Sale Report</b></h3>
          </div>
           <p>A sale analysis report shows the trend that occur in a company's sale volume over time.In its most baisc form, a sale analysis report shows whether sales are increasing or declining.</p>
        </div>  
      </div>
    </div>
    <?php require_once 'footer.php'; ?>
  <!-- SCRIPTS -->

  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>
  <script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.bundle.js"></script>
  <script type="text/javascript" src="js/style.js"></script>






</body>

</html>
