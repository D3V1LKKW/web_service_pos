<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <title>About</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">

  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
  <style>
    .cust-grid{
      display: flex;
      justify-content: center;
      flex-flow:row wrap;
    }
  </style>
</head>
<body>
  <?php require_once 'header.php'; ?>
  <br>
  <br>
  <div class="container">
     <div class="row cust-grid">
        <div class="col-sm-4">
          <div class="text-center">
           <img src="images/test.jpg" class="rounded-circle" width="150" height="150" alt="ing-fluit img-responsive">
           <p>Daw Phyo Phyo Wai</p>
           <p>09977284648</p>
           <p>phyophyowai@gmail.com</p>
          </div> 
        </div>
      </div><br><br><br>
      <div class="row cust-grid">
        <div class="col-sm-4">
          <div class="text-center">  
           <img src="images/test.jpg" class="rounded-circle" width="150" height="150" alt="ing-fluit img-responsive">
           <p>Mg Kaung Khant Win</p>
           <p>09969984443</p>
           <p>kaungkhantwinn.ucsmgy@gmail.com</p>
          </div>
        </div>
        <div class="col-sm-4">
          <div class="text-center">  
           <img src="images/test.jpg" class="rounded-circle" width="150" height="150" alt="ing-fluit img-responsive">
           <p>Ma Nway Nway Nandar</p>
           <p>09951042324</p>
           <p>nwaynwaynandar7@gmail.com</p>
          </div>
        </div>
        <div class="col-sm-4">
          <div class="text-center">  
           <img src="images/test.jpg" class="rounded-circle" width="150" height="150" alt="ing-fluit img-responsive">
           <p>Ma Phyo Myat Thu</p>
           <p>09951424842</p>
           <p>phyo76767@gmail.com</p>
          </div>
        </div>
      </div><br><br><br>
      <div class="row cust-grid">        
        <div class="col-sm-4">
          <div class="text-center">
           <img src="images/test.jpg" class="rounded-circle" width="150" height="150" alt="ing-fluit img-responsive">
           <p>Ma Moh Moh Shwe Sin Win</p>
           <p>09951093821</p>
           <p>mohmohszw@gmail.com</p>
          </div>
        </div>
        <div class="col-sm-4">
          <div class="text-center">
           <img src="images/test.jpg" class="rounded-circle" width="150" height="150" alt="ing-fluit img-responsive">
           <p>Ma Kyi Phyu Thant</p>
           <p>09977284648</p>
           <p>kyiphyu0622@gmail.com</p>
          </div>
        </div>
        <div class="col-sm-4">
          <div class="text-center">
           <img src="images/test.jpg" class="rounded-circle" width="150" height="150" alt="ing-fluit img-responsive">
           <p>Ma Wint Wah Thant</p>
           <p>09792493949</p>
           <p>wintwahthant345@gmail.com</p>
          </div>
        </div>  
      </div>
    </div>
    <?php require_once 'footer.php'; ?>
</body>
</html>
