<body>
	<hr>
	&copy; <?php echo date ('Y'); ?>
</body>