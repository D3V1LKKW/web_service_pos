<?php
session_start();
if (isset($_SESSION["script_inject"])) {
	echo "<script>alert(\"Don't Inject My Site\")</script>";
	unset($_SESSION["script_inject"]);
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Register Form</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<style>
    body{
    background-color: #4e8bed;
}
.centered-form{
	margin-top: 60px;
}

.centered-form .panel{
	background: rgba(255,255,255, 0.5);
	box-shadow: rgba(0, 0, 0, 0.3) 20px 20px 20px;
}
</style>
<script type="text/javascript">
				 	 var countryLists= new Array(15);
				 	countryLists["empty"] = ["select a city"];
					countryLists["Kachin"]=["MyitKyiNar", "BaMaw"];
					countryLists["Kayah"] = ["Loikaw", "Demoso"];
					countryLists["Kayin"] =[ "Hapan", "Phado"];
					countryLists["Chin"] = ["Hakha", "Paletwa"];
					countryLists["Mon"] = ["Mawlamyine", "Mudon"];
					countryLists["Rakhine"] = ["Sittwe", "Tantwe"];
					countryLists["Shan"] =["Tanunggyi", "Lashio"];
					countryLists["Magway"] = ["Magway", "Minbu"];
					countryLists["Mandalay"] = ["Mandalay", "Bagan"];
					countryLists["Yangon"] = ["Yangon", "Thanhlan"];
					countryLists["Bago"] = ["Baga","Pyay"];
					countryLists["Ayeyarwady"]= ["Hinthada", "Pathein"];
					countryLists["Sagaing"] = ["Sagaing" ,"Moneyar"];
					countryLists["Thinthary"] = ["Htarwae" ,"Myake"];
					function countryChange(selectObj){
						var idx= selectObj.selectedIndex;
						var which= selectObj.options[idx].value;
						var clist= countryLists[which];
						var cSelect= document.getElementById("city");
						var len= cSelect.options.length;
						while(cSelect.options.length>0)
						{
							cSelect.remove(0);
						}
						var newOption;
						for(i=0; i<clist.length; i++)
						{
							newOption = document.createElement("option");
							newOption.value= clist[i];
							newOption.text= clist[i];
							try{
								cSelect.add(newOption);
							}
							catch(e){
								cSelect.appendChild(newOption);
							}
						}
					}
					function cityChange(selectCityObj)
					{
						var idx= selectObj.selectedIndex;
						var which= selectCityObj.options[idx].value;
						var a =document.getElementById("selectCity");
						a.innerHTML = which;
					}

					function isNumber(event){
						var keycode = event.keyCode;
						if(keycode > 47 && keycode <58){
							return true;
						}
						return false;
					}

					function isAlphabet(event){
						var keycode = event.keyCode;
						if((keycode > 64 && keycode <91) || (keycode > 96 && keycode < 123) || keycode === 32){
							return true;
						}
						return false;
					}

					function addHyphen(element){
						let ele = document.getElementById(element.id);
						ele = ele.value.split('-').join('');
						let finalVal = ele.match(/.{1,5}/g).join('-');
        				document.getElementById(element.id).value = finalVal;
					}
				</script>
</head>
<body>
<div calss="container">
    <div class="row centered-form">
    	<div class="col-xs-12 col-sm-8 col-md-4 col-sm-offset-2 col-md-offset-4">
        	<div class="panel panel-default">
        	<div class="panel-heading">
        	<h3 class="pnael-title">Register Form</h3>
        	</div>
        	<div class="panel-body">
        	<form method="post" action="./utils/register_authenticate.php">
        	<div class="row">
        	<div class="col-xs-6 col-sm-6 col-md-6">
        	<div class="form-group">
        	<input type="text" name="fname" id="fname" class="form-control input-sm" placeholder="First Name" onkeypress="return isAlphabet(event)" required>
        	</div>
        	</div>
        	<div class="col-xs-6 col-sm-6 col-md-6">
        	<div class="form-group">
        	<input type="text" name="lname" id="lname" class="form-control input-sm" placeholder="Last Name" onkeypress="return isAlphabet(event)" required>
        	</div>
        	</div>
        	</div>
        	<div class="form-group">
        	<label for="cname">Company Name</label>
			<input type="text" name="cname" id="cname" class="form-control input-sm" onkeypress="return isAlphabet(event)" required>
			</div>
			<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6">
			<div class="form-group">
			<label for="contient">State</label>
			<select id= "contient" name="state" class="form-control" onchange="countryChange(this)">
				<option value="empty">Select a state</option>
				<option value="Kachin">Kachin</option>
				<option value="Kayah">Kayah</option>
				<option value="Kayin">Kayin</option>
				<option value="Chin">Chin</option>
				<option value="Mon">Mon</option>
				<option value="Rakhine">Rakhine</option>
				<option value="Shan">Shan</option>
				<option value="Magway">Magway</option>
				<option value="Mandalay">Mandalay</option>
				<option value="Yangon">Yangon</option>
				<option value="Bago">Bago</option>
				<option value="Ayeyarwady">Ayeyarwady</option>
				<option value="Sagaing">Sagaing</option>
				<option value="Thinthary">Thinthary</option>
			</select>
      		</div>
      		</div>
      		<div class="col-xs-6 col-sm-6 col-md-6">
			<div class="form-group">
			<label for="city">City</label>
			<select id="city" name="city"  class= "form-control"onchange="cityChange(this);">
				<option value=0>Select a city</option>
			</select>
			</div>
			</div>
		</div>
		<div class="form-group">
			<?php
if (isset($_SESSION["state_error"])) {
    echo "
					<span class=\"label label-danger\">" . $_SESSION["state_error"] . "</span>";
    unset($_SESSION["state_error"]);
}
?>
		</div>
			<div class="form-group">
			<label for="address">Address:</label>
			 <textarea class="form-control" id="address" name="address" placeholder="Please enter your Address here..." rows="3"></textarea>
			</div>
			<div class="form-group">
			<label for="card">Phone Number</label>
			<input type="text" name="ph_no" id="ph_no" class="form-control input-sm" maxlength="11" autocomplete="off" onkeypress="return isNumber(event)" required>
			</div>

			<div class="form-group">
			<label for="email">Company Email:</label>
			<input type="text" name="email" id="email" class="form-control input-sm" autocomplete="off" required>
			<?php
if (isset($_SESSION["email_error"])) {
    echo "
					<span class=\"label label-danger\">" . $_SESSION["email_error"] . "</span>";
    unset($_SESSION["email_error"]);
}
?>
			</div>
			<div class="form-group">
			<label for="card">Credit Card</label>
			<input type="text" name="card" id="card" class="form-control input-sm" maxlength="17" autocomplete="off" onkeyup="addHyphen(this)" onkeypress="return isNumber(event)" required>
			<?php
if (isset($_SESSION["card_error"])) {
    echo "
					<span class=\"label label-danger\">" . $_SESSION["card_error"] . "</span>";
    unset($_SESSION["card_error"]);
}
?>
			</div>
			<div class="form-group">
			<label for="exdate">Expire Date</label>
			<input type="date" name="date" id="date" class="form-control input-sm" placeholder="Expire Date">
			<?php
if (isset($_SESSION["date_error"])) {
    echo "
					<span class=\"label label-danger\">" . $_SESSION["date_error"] . "</span>";
    unset($_SESSION["date_error"]);
}
?>

			<?php
if (isset($_SESSION["date_not_equal"])) {
    echo "
					<span class=\"label label-danger\">" . $_SESSION["date_not_equal"] . "</span>";
    unset($_SESSION["date_not_equal"]);
}
?>

			</div>
			<label for="radio"><b>Plan</b></label>
			<div calss="form-group">
			<label class="form-check form-check-inline">
			<input class="form-check-input" type="radio" name="plan" value="6" checked="checked">
		  	<span class="form-check-label"> 6months </span>
			</label>
			<label class="form-check form-check-inline">
			<input class="form-check-input" type="radio" name="plan" value="12">
		 	<span class="form-check-label"> 12months</span>
			</label>
			</div>
		<input type="submit" value="Register" class="btn btn-info btn-block">
	</div>
		</form>
	     </div>

        	</div>
        </div>
    </div>
</div>

</body>
</html>
<?php
session_destroy();
?>